---
description: Add a compact second act to /scan explaining what three bills means and what the customer receives after the review.
---

# Chunk 3: What You Receive and Three-Bill Guidance

## Goal

Give the page a complete second act without turning it into a long marketing page.

Add one compact section below the hero.

## Why this exists

The current page ends too early.

The visitor needs answers to:

```text
What does "three bills" mean?
What does Costivra actually give me?
```

## Section 1: What three bills means

Add a quiet guidance block.

Headline:

```text
Choose the three bills that tell you the most.
```

Supporting copy:

```text
Upload three current bills from different vendors for a broader review, or
include two or three recent bills from the same vendor to see what changed over
time.
```

Add two non-interactive guidance options:

### Track a change

```text
3 recent bills from one vendor
```

Supporting note:

```text
Best for spotting price changes, new fees, or usage shifts.
```

### Scan broadly

```text
1 current bill from up to 3 vendors
```

Supporting note:

```text
Best for identifying which recurring costs deserve a deeper review first.
```

These are guidance, not required choices.

Do not force the customer to select a review type.

## Section 2: What you receive

Eyebrow:

```text
WHAT YOU RECEIVE
```

Use three columns.

### A structured breakdown

```text
Amounts, dates, billing periods, charges, account details, and other fields
Costivra can support from the source.
```

### Review findings

```text
Unusual charges, missing information, renewal risks, and other items that
deserve confirmation.
```

### Source evidence

```text
Every material observation points back to the uploaded file so you can review
the source yourself.
```

## Important wording rules

Do not promise:

```text
Guaranteed savings
Guaranteed errors
Guaranteed cost leaks
Guaranteed benchmark
```

Do not imply every uploaded document will create a finding.

Use:

```text
items that deserve attention
review findings
supported source facts
```

## Visual design

Keep this section compact.

Recommended:

```text
one bordered strip
or
three equal columns separated by subtle lines
```

Do not use three giant elevated cards.

No carousels.

No fake screenshots.

No testimonials in this chunk.

## Optional micro-proof

If current product truth supports it, add a compact line:

```text
Bills remain private to your organization. Costivra does not contact vendors
without your approval.
```

Do not repeat the entire trust footer from the conversion card.

## Mobile

Stack the two guidance modes.

Stack the three deliverables.

Use clear separators.

## Validation

The visitor should be able to answer:

```text
Should I upload three different vendors or three months of one vendor?
What will I see after the upload?
```

without opening another page.

## Exit gate

Chunk complete only when:

```text
The page no longer feels unfinished below the hero
Meaning of three bills is clear
Deliverables are clear
No unsupported promise was introduced
Section remains compact and premium
Mobile stacking is clean
```
