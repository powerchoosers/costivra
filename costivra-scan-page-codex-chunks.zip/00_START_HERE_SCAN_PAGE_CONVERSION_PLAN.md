---
description: Master execution order for improving Costivra's /scan page into a high-intent conversion step without overloading the page.
---

# Costivra /scan Page Conversion Sprint

## Purpose

This packet improves:

```text
https://costivra.ai/scan
```

The page is already visually credible. The job is not to redesign Costivra. The job is to make `/scan` work harder as a **high-intent conversion page**.

The visitor has already clicked:

```text
Scan 3 bills free
```

That means `/scan` must feel like **Step 1 of the scan**, not an informational stop before the scan.

## Current product truth

The current funnel is approximately:

```text
Homepage CTA
-> /scan
-> Create secure workspace
-> Signup
-> Email confirmation
-> Customer app
-> Upload
```

The page currently explains security reasonably well, but does not explain enough about:

```text
What the customer should upload
What they will receive
Why an account is required
What happens after they click
```

## Product objective

The finished page should make these statements obvious without the visitor having to think:

```text
I know what to upload.
I know what Costivra will give me.
I understand why I need a secure account.
I know exactly what happens next.
```

## Preserve

Keep:

- The serif editorial headline style
- The restrained paper/grid background
- The bordered white conversion card
- The bright primary CTA
- The security emphasis
- "No vendor contact without approval"
- The overall calm, premium visual language
- Existing responsive and accessibility patterns

Do not turn the page into a marketing carousel, testimonial wall, fake dashboard, or decorative illustration farm.

## Change

Improve:

- Oversized hero balance
- Left/right visual weight
- Meaning of "three bills"
- Customer-facing security copy
- Step visibility
- Deliverable clarity
- CTA duplication
- Post-signup destination
- Below-the-fold completeness

## Recommended final page model

### Left side

```text
FREE 3-BILL REVIEW

Upload three bills.
See what deserves attention.

Costivra reviews recurring business bills and contracts for
price changes, unusual fees, duplicate costs, missing terms,
and renewal risks. Every material finding stays connected to
the source document.

Upload three current bills from different vendors, or include
multiple months from one vendor to review changes over time.
```

### Right conversion card

```text
STEP 1 OF 3

Start your secure review

Create a private Costivra workspace, upload up to three bills
or contracts, and review the extracted facts before anything
becomes an action.

1. Create your workspace
2. Upload your documents
3. Review your breakdown

[ Create workspace and continue -> ]

Already have an account? Sign in

Private to your organization
No broad inbox access
No vendor contact without approval
```

### Second section

```text
WHAT YOU RECEIVE

A structured breakdown
Amounts, dates, billing periods, charges, and account details.

Review findings
Unusual charges, missing information, and renewal risks that
deserve confirmation.

Source evidence
Every material observation points back to the uploaded file.
```

## Recommended chunk order

Run one file at a time.

```text
01_HERO_COPY_AND_LAYOUT_BALANCE.md
02_CONVERSION_CARD_AND_FUNNEL_CLARITY.md
03_WHAT_YOU_RECEIVE_AND_THREE_BILL_GUIDANCE.md
04_HEADER_CTA_ROUTING_AND_FUNNEL_DESTINATION.md
05_RESPONSIVE_ACCESSIBILITY_AND_CONVERSION_QA.md
```

## Branch strategy

Recommended:

```text
codex/scan-page-01-hero
codex/scan-page-02-card
codex/scan-page-03-deliverable
codex/scan-page-04-routing
codex/scan-page-05-qa
```

Start every chunk from the latest merged `main`.

## Standard Codex prompt

Use:

```text
Read AGENTS.md, DECISIONS.md, STATUS.md,
00_START_HERE_SCAN_PAGE_CONVERSION_PLAN.md,
and <SELECTED_CHUNK>.md completely.

Execute only the selected chunk.

Inspect the current /scan implementation before editing. Preserve the existing
Costivra visual system. Do not begin later chunks. Implement the changes,
run focused validation, inspect desktop and mobile behavior, and stop only
when this chunk's exit gate is satisfied.
```

## Global guardrails

Do not:

- Add fake savings claims
- Add testimonials without real approved customer proof
- Name Supabase in customer-facing scan copy
- Add broad inbox-access claims
- Auto-upload anything before account creation
- Add unnecessary decorative art
- Create fake progress metrics
- Remove the secure-account requirement
- Change legal or security promises without evidence
- Redesign the entire marketing site
- Expand this sprint into the customer app

## Final completion standard

The sprint is complete when:

```text
Hero feels visually balanced
The conversion card feels like Step 1
The visitor understands what to upload
The visitor understands what they receive
The header CTA no longer points to the page the visitor is already on
Signup points to the correct customer destination
Desktop and mobile layouts feel intentional
The page remains calm and premium
Full quality gate is green
```
