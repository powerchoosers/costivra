---
description: Fix the self-linking /scan header CTA and route scan conversions into the simplified customer Bills & Spend experience.
---

# Chunk 4: Header CTA and Funnel Destination

## Goal

Make every CTA on `/scan` move the visitor forward instead of pointing back to the same page or into a technical document-storage screen.

Inspect the current customer-app information architecture before editing.

## Current problem

The marketing header uses:

```text
Scan 3 bills free
-> /scan
```

on every marketing page.

That means on `/scan` the primary header CTA points to the page the visitor is already viewing.

The scan card currently routes through:

```text
/signup?next=/app/documents
/login?next=/app/documents
```

The customer-facing app is being simplified around:

```text
Bills & Spend
```

rather than exposing Documents as the main destination.

## Scan-page-specific header CTA

When pathname is:

```text
/scan
```

change the top-right primary CTA to:

```text
Create workspace
```

Route:

```text
/signup?next=/app/bills
```

If the unified Bills & Spend route has not yet shipped, use the current intended route but add a TODO tied to the IA release.

Do not route to a nonexistent page.

## Scan card primary CTA

Use:

```text
Create workspace and continue
```

Route to:

```text
/signup?next=/app/bills
```

after the Bills & Spend route exists.

## Existing account link

Use:

```text
/login?next=/app/bills
```

after the route exists.

## Backward compatibility

If the application currently redirects legacy paths:

```text
/app/documents
/app/expenses
```

confirm those redirects do not create loops.

## Preserve marketing behavior elsewhere

On all other marketing pages:

```text
Scan 3 bills free
-> /scan
```

remains correct.

Do not globally replace the CTA.

## Optional funnel source tracking

Add safe query context:

```text
?source=scan
```

only if the current analytics system already has a pattern for this.

Do not introduce a new analytics provider solely for this task.

## Email confirmation behavior

Verify signup confirmation preserves the intended `next` destination safely.

Do not allow an arbitrary open redirect.

Allowed post-auth paths must remain internal.

## Returning users

When a signed-in user visits `/scan`, consider showing:

```text
Go to Bills & Spend
```

rather than asking them to create another workspace.

Only implement this if the marketing route can determine session state without harming caching or page behavior.

Otherwise leave signed-in optimization for a later chunk.

## Tests

Add:

- `/scan` header CTA points forward
- Other marketing pages still point to `/scan`
- Signup next path is correct
- Login next path is correct
- Unsafe external next URL is rejected by auth flow
- Legacy document route does not loop

## Exit gate

Chunk complete only when:

```text
No primary CTA on /scan links back to /scan
Signup moves toward the bill-review workflow
Login preserves the same destination
Other marketing CTAs remain unchanged
No redirect loop exists
```
