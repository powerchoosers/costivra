---
description: Turn the /scan right-side card into a clear Step 1 conversion surface with one dominant action and a visible three-step funnel.
---

# Chunk 2: Conversion Card and Funnel Clarity

## Goal

Transform the right-side card from a security notice into the first visible step of the three-bill review.

Do not modify the signup flow itself in this chunk.

## Current card problems

Current card emphasizes:

```text
Free Cost Leak Scan
Secure account required
Security explanation
Create workspace
I already have an account
```

Problems:

- "Secure account required" sounds like a barrier
- "Cost Leak Scan" sounds promotional
- The card does not explain the process
- The full-width secondary login button competes with the primary CTA
- It does not visually balance the left hero

## New card header

Replace:

```text
Free Cost Leak Scan
SECURE ACCOUNT REQUIRED
```

with:

```text
Free 3-Bill Review
STEP 1 OF 3
```

Alternative accepted title:

```text
Free Recurring Cost Review
```

Do not use "Cost Leak Scan" as the card title.

## New card body

Use:

```text
Start your secure review

Create a private Costivra workspace, upload up to three bills or contracts,
and review the extracted facts before anything becomes an action.
```

## Add a visible three-step sequence

Create three restrained rows:

```text
01  Create your workspace
02  Upload your documents
03  Review your breakdown
```

Each row should contain:

- Number
- Short title
- Optional one-line supporting copy

Do not turn the stepper into a large timeline graphic.

## Primary CTA

Use:

```text
Create workspace and continue
```

Retain arrow icon.

This is the only large full-width CTA in the card.

## Existing account treatment

Replace the full-width secondary button:

```text
I already have an account
```

with compact text:

```text
Already have an account? Sign in
```

The link remains easy to click.

Do not visually compete with the primary CTA.

## Trust footer

Move the existing assurances into the bottom of the card:

```text
Private to your organization
No broad inbox access
No vendor contact without approval
```

Use small checks or shield icons.

Do not mention infrastructure providers.

## Security copy

Remove:

```text
Your source documents deserve a real security boundary.
```

if it competes with the funnel language.

Security should support the conversion rather than become the entire conversion message.

A concise note is enough:

```text
Your documents stay private to your organization and are reviewed only after
you choose to upload them.
```

Only use copy that matches actual product behavior.

## Card height

The new stepper and trust footer should naturally increase the card height and improve the page's visual balance.

Do not artificially set a giant fixed height.

## Styling

Preserve:

- White surface
- Thin border
- Rounded corners
- Existing button language
- Calm typography
- Lime CTA if that is the current scan-page visual system

Add subtle internal separators rather than nested cards.

## Accessible stepper

Use an ordered list:

```html
<ol>
```

Each step should be semantically readable.

## Mobile

Card becomes full-width below the hero.

CTA remains full-width.

Compact login treatment must not become too small to tap.

## Validation

Confirm the card answers:

```text
Where am I?
Why do I need an account?
What happens after account creation?
What happens after upload?
```

## Exit gate

Chunk complete only when:

```text
The card visibly says Step 1 of 3
The process is understandable in under 5 seconds
There is one dominant CTA
Sign in is secondary
Trust assurances are inside the card
The card visually balances the hero
Desktop and mobile QA pass
```
