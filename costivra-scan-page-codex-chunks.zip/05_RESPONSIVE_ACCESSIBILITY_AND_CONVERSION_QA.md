---
description: Perform final desktop, mobile, keyboard, accessibility, and conversion QA on Costivra's redesigned /scan page.
---

# Chunk 5: Responsive, Accessibility, and Conversion QA

## Goal

Prove the new `/scan` page works as a high-intent conversion step.

Do not add new marketing content during this chunk unless QA exposes a clear defect.

## Viewports

Inspect:

```text
1440 x 900
1280 x 800
1024 x 768
820 x 1180
390 x 844
375 x 812
```

## First-screen checks

At 1440 x 900, confirm the visitor can see without scrolling:

```text
Free 3-Bill Review eyebrow
Full headline
Core explanation
At least most of the conversion card
Primary CTA
Step 1 of 3
```

Do not require the visitor to scroll before understanding what happens next.

## Balance checks

Verify:

- Hero does not dominate the entire screen
- Card does not feel tiny next to the hero
- Column gap feels intentional
- No giant dead zone
- Whitespace feels premium rather than unfinished

## Content checks

The page must answer:

```text
What do I upload?
What does Costivra review?
What do I receive?
Why is an account required?
What happens next?
```

## CTA checks

Confirm:

```text
Header primary CTA
Card primary CTA
Existing-account link
```

all behave correctly.

There should be one obvious primary action in the hero.

## Keyboard

Tab through:

```text
Logo
Navigation
Sign in
Header CTA
Card CTA
Sign in link
Footer links
```

Check:

- Visible focus
- Logical order
- No focus trap
- No duplicate inaccessible link
- No invisible clickable area

## Screen-reader semantics

Verify:

```text
One H1
Logical H2 hierarchy
Ordered list for three steps
Links describe destination
Decorative icons hidden
No text conveyed only by color
```

## Contrast

Check:

- Lime CTA text
- Muted guidance
- Step numbers
- Secondary sign-in link
- Trust footer
- Eyebrow labels

Do not weaken brand colors unnecessarily.

## Reduced motion

If reveal or hover animations are present:

```text
prefers-reduced-motion: reduce
```

must reduce nonessential movement.

## Mobile

On mobile:

```text
Headline does not become excessively tall
Card CTA remains prominent
Card stepper is readable
Guidance modes stack cleanly
Deliverables stack cleanly
No horizontal scrolling
No clipped footer
```

## Performance

Do not introduce:

- Large image payloads
- Client libraries solely for this page
- Additional blocking fonts
- Heavy animation dependencies

## Conversion event QA

If current analytics exist, verify these existing or new events:

```text
scan_page_view
scan_signup_click
scan_login_click
```

Do not add event tracking if there is no reviewed analytics infrastructure.

## Browser screenshots

Capture:

```text
scan-desktop-first-screen.png
scan-desktop-full-page.png
scan-tablet.png
scan-mobile-first-screen.png
scan-mobile-full-page.png
```

Store in the existing QA artifact convention.

## Final quality gate

Run:

```bash
npm ci
npm run typecheck
npm run lint
npm test
npm run build
npm run test:e2e
```

If the repository quality gate includes additional commands, run those too.

## Final acceptance

The page is complete when:

```text
It feels like Step 1, not a gate before Step 1
One primary action is obvious
The visitor understands three-bill guidance
The visitor knows what they receive
Security supports the conversion rather than dominating it
Desktop composition is balanced
Mobile is intentional
No self-linking CTA remains
Full quality gate passes
```

## Final report

Provide:

```text
Changed files
Before/after funnel
Desktop screenshots
Mobile screenshots
CTA routes
Accessibility result
Quality-gate result
Remaining limitations
```
