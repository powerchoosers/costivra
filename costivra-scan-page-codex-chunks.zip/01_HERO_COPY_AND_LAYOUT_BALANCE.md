---
description: Rebalance the /scan hero, reduce oversized whitespace, and replace the current copy with a clearer high-intent conversion message.
---

# Chunk 1: Hero Copy and Layout Balance

## Goal

Fix the first-screen composition without changing the funnel mechanics yet.

Primary files likely include:

```text
src/components/marketing-pages.tsx
src/app/globals.css
```

Inspect current implementation before editing.

## Current visual problem

The page currently uses a large editorial headline inside a wide content-page layout.

The effect is:

```text
Left side:
very large headline
paragraph
three assurances

Right side:
smaller security card
two buttons
```

The page is technically aligned but visually lopsided.

The left reads like a magazine cover.

The right reads like a utility form.

## New hero copy

Add an eyebrow above the headline:

```text
FREE 3-BILL REVIEW
```

Replace:

```text
Start with three bills.
```

with:

```text
Upload three bills.
See what deserves attention.
```

Recommended body:

```text
Costivra reviews recurring business bills and contracts for price changes,
unusual fees, duplicate costs, missing terms, and renewal risks. Every material
finding stays connected to the source document.
```

Recommended guidance copy below:

```text
Upload three current bills from different vendors, or include multiple months
from one vendor to review changes over time.
```

## Customer-facing terminology

Do not use:

```text
Supabase
private Supabase storage
structured extraction
cost leak
```

in the primary conversion copy.

Prefer:

```text
private Costivra workspace
structured bill breakdown
review findings
source evidence
```

## Layout targets

Desktop:

```text
Content top padding:
approximately 110 to 120px

Hero columns:
approximately 1.05fr / .95fr

Column gap:
approximately 64 to 72px
```

Do not hardcode these values blindly. Fit them to the current marketing container and header.

## Headline sizing

Reduce the current scan-specific hero size by roughly 15 to 20 percent.

Do not globally shrink every content-page headline.

Create scan-specific classes such as:

```text
scan-page
scan-hero
scan-hero-copy
scan-hero-title
```

The scan page should not inherit every oversized editorial content-page rule.

## Vertical rhythm

The left column should feel complete before the conversion card ends.

Recommended structure:

```text
Eyebrow
Headline
Body
Guidance
```

Move the three existing assurance lines out of the left column in Chunk 2.

Do not leave a long vertical checklist under the hero.

## Widths

Recommended:

```text
Headline max width:
roughly 650 to 720px

Body max width:
roughly 620px

Guidance max width:
roughly 600px
```

The second headline line should not feel stranded.

## Visual hierarchy

Order:

```text
1. Headline
2. Primary promise
3. What to upload guidance
4. Conversion card
```

Avoid adding more icons to the left.

## Motion

If the marketing system already uses reveal animations, preserve them.

Do not add a hero animation solely for this page.

## Mobile

On mobile:

```text
Eyebrow
Headline
Body
Guidance
Conversion card
```

Headline should remain strong but fit comfortably without 3 to 4 oversized lines.

Recommended mobile title target:

```text
roughly 2.8rem to 3.6rem
```

depending on viewport.

## Validation

Inspect:

```text
1440 x 900
1024 x 768
820 x 1180
390 x 844
375 x 812
```

Check:

- No horizontal overflow
- Hero does not collide with sticky header
- Left and right weights feel balanced
- Headline remains premium
- Guidance is easy to scan
- No giant dead zone under the left content

## Exit gate

Chunk complete only when:

```text
The hero no longer feels lopsided
The page clearly communicates what is being uploaded
No customer-facing Supabase language remains in the hero
Headline is still distinctly Costivra
Mobile hero is comfortable and readable
Typecheck, lint, and focused tests pass
```
